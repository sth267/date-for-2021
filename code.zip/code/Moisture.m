clear
str = '/Users/mac/Desktop/code/Moisture';
files = dir(strcat(str,'*.xlsx'));
number_files = length(files);
data = zeros(501,2);
for i = 1:number_files
    data = data + xlsread([str,files(i).name],'B2:C502');
end
data = data ./ number_files;
x = data(1:501,1);
y = data(1:501,2);
plot(x,y,'.r');
grid on;
hold on;

p1 = polyfit(x,y,7)
X1 = -5:0.01:0;
Y1 = polyval(p1,X1);
plot(X1,Y1,'g');
hold on;
axis([-5 0 0 10]);
xlabel('Moisture');
ylabel('Growth-rate');