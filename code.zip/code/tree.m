clear all;
clc;
warning off;

data = xlsread('/Users/mac/Desktop/code/T2.xlsx','A1:L615');

a = randperm(615);
Train = data(a(1:550),:);
Test = data(a(550:end),:);

P_train = Train(:,2:end);
T_train = Train(:,1);

P_test = Test(:,2:end);
T_test = Test(:,1);

ctree = ClassificationTree.fit(P_train,T_train);

view(ctree);
view(ctree,'mode','graph');

T_sim = predict(ctree,P_test);

count_B = length(find(T_train == 1));
count_M = length(find(T_train == 0));
count_R = length(find(T_train == -1));

rate_B = count_B / 550;
rate_M = count_M / 550;
rate_R = count_R / 550;

total_B = length(find(data(:,1) == 1));
total_M = length(find(data(:,1) == 0));
total_R = length(find(data(:,1) == -1));

number_B = length(find(T_test == 1));
number_M = length(find(T_test == 0));
number_R = length(find(T_test == -1));

number_B_sim = length(find(T_sim == 1 & T_test == 1));
number_M_sim = length(find(T_sim == 0 & T_test == 0));
number_R_sim = length(find(T_sim == -1 & T_test == -1));

disp(['Total number of experiments��' num2str(615)...
      '  A Win��' num2str(total_B)...
      '  Coexistence��' num2str(total_M)...
      '  B Win��' num2str(total_R)]);
  
disp(['Total number of training set experiments��' num2str(550)...
      '  A Win��' num2str(count_B)...
      '  Coexistence��' num2str(count_M)...
      '  B Win��' num2str(count_R)]);
  
disp(['Total number of test set experiments��' num2str(65)...
      '  A Win��' num2str(number_B)...
      '  Coexistence��' num2str(number_M)...
      '  B Win��' num2str(number_R)]);
  
disp(['Total number of A_Win results��' num2str(number_B_sim)...
      '  Error��' num2str(number_B - number_B_sim)...
      '  Accuracy p1=' num2str(number_B_sim/number_B*100) '%']);
  
disp(['Total number of coexistence results��' num2str(number_M_sim)...
      '  Error��' num2str(number_M - number_M_sim)...
      '  Accuracy p2=' num2str(number_M_sim/number_M*100) '%']);
  
disp(['Total number of B_Win results��' num2str(number_R_sim)...
      '  Error��' num2str(number_R - number_R_sim)...
      '  Accuracy p3=' num2str(number_R_sim/number_R*100) '%']);
  

leafs = logspace(1,2,10);
 
N = numel(leafs);
 
err = zeros(N,1);
for n = 1:N
    t = ClassificationTree.fit(P_train,T_train,'crossval','on','minleaf',leafs(n));
    err(n) = kfoldLoss(t);
end
plot(leafs,err);
xlabel('Minimum number of samples contained in leaf nodes');
ylabel('Cross validation error');
title('Influence of the minimum number of samples contained in leaf nodes on the performance of decision tree')

OptimalTree = ClassificationTree.fit(P_train,T_train,'minleaf',13);
view(OptimalTree,'mode','graph')

resubOpt = resubLoss(OptimalTree)
lossOpt = kfoldLoss(crossval(OptimalTree))

resubDefault = resubLoss(ctree)
lossDefault = kfoldLoss(crossval(ctree))

[~,~,~,bestlevel] = cvLoss(ctree,'subtrees','all','treesize','min')
cptree = prune(ctree,'Level',bestlevel);
view(cptree,'mode','graph')

resubPrune = resubLoss(cptree)
lossPrune = kfoldLoss(crossval(cptree))
 

