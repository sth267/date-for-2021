clear
str = '/Users/mac/Desktop/code/Temperature/';
files = dir(strcat(str,'*.xlsx'));
number_files = length(files);
data = zeros(5500,2);
for i = 1:number_files
    data = data + xlsread([str,files(i).name],'B2:C5501');
end
data = data ./ number_files;
x = data(1:5500,1);
y = data(1:5500,2);

plot(x,y,'.r');
grid on;
hold on;
p1 = polyfit(x,y,9)
X1 = -5:0.01:50;
Y1 = polyval(p1,X1);
plot(X1,Y1,'g');
hold on;
axis([-5 50 0 10]);
xlabel('Temperature');
ylabel('Growth-rate');